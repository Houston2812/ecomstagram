module.exports = {
    secret: 'fbd0f530718823d4ddc66674970cc4f0',
    user: 'ecomstagram@gmail.com',
    pass: 'bl0ck_ch41n',
    sessionSecret: 'bc8686134dd6000979eac326e631b0d3',
    db_pass: 'password',
    publishable_key: 'pk_test_51Iiwn6GdXLmkg9KwgljpA2qLwQMfppMtXj5b4MNQ5HabN3JtxQmk1l1IPsgiSoogpJ7hghj1MvuMOpTyrdrfoQ6200BytOVUCo',
    secret_key: 'sk_test_51Iiwn6GdXLmkg9KwmRogSWcpE3fIS2K9EeUR7YDDSlGDMEzjxTfMlkQKQ2bydi1FC2Ls5qTKFR9w9VvUOvFyCjOL00JYKag1xJ'
}

// -- 1A2B3c4d_